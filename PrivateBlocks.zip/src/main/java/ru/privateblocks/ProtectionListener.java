package ru.privateblocks;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public class ProtectionListener implements Listener {

    private final PrivateBlocks plugin;

    public ProtectionListener(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    private RegionManager rm() {
        return plugin.regions();
    }

    // ---------- Установка блоков / создание привата ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlockPlaced();
        String typeId = plugin.typeOf(e.getItemInHand());

        if (typeId != null) {
            ConfigurationSection s = plugin.type(typeId);
            if (s == null) {
                e.setCancelled(true);
                p.sendMessage(plugin.msg("unknown-type", "%type%", typeId));
                return;
            }
            if (!p.hasPermission("privateblocks.use")) {
                e.setCancelled(true);
                p.sendMessage(plugin.msg("no-permission"));
                return;
            }
            if (s.getStringList("disabled-worlds").contains(b.getWorld().getName())) {
                e.setCancelled(true);
                p.sendMessage(plugin.msg("disabled-world"));
                return;
            }
            int max = s.getInt("max-per-player", 0);
            if (max > 0 && !plugin.canBypass(p) && rm().count(p.getUniqueId(), typeId) >= max) {
                e.setCancelled(true);
                p.sendMessage(plugin.msg("limit", "%max%", String.valueOf(max)));
                return;
            }

            Region r = new Region(UUID.randomUUID(), p.getUniqueId(), b.getWorld().getName(),
                    b.getX(), b.getY(), b.getZ(), s.getInt("radius", 5), typeId,
                    s.getBoolean("full-height", true));

            for (Region other : rm().all()) {
                if (other.intersects(r) && !(other.owner.equals(p.getUniqueId()) && plugin.canBypass(p))) {
                    e.setCancelled(true);
                    p.sendMessage(plugin.msg("overlap"));
                    return;
                }
            }

            ConfigurationSection fs = s.getConfigurationSection("flags");
            for (String flag : Region.ALL_FLAGS) {
                r.flags.put(flag, fs != null && fs.getBoolean(flag, false));
            }
            rm().add(r);
            p.sendMessage(plugin.msg("created", "%radius%", String.valueOf(r.radius)));
            if (s.getBoolean("custom-size", false)) {
                // сразу выдаём 2 кровати для выбора размера (на следующем тике, после установки блока)
                Bukkit.getScheduler().runTask(plugin, () -> plugin.sizeSelector().start(p, r));
            }
            return;
        }

        Region r = rm().getAt(b.getLocation());
        if (!plugin.allowed(p, r, "build")) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("denied"));
        }
    }

    // ---------- Ломание блоков / снятие привата ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();

        Region center = rm().getByCenter(b);
        if (center != null) {
            if (center.owner.equals(p.getUniqueId()) || (!plugin.noBypass(center) && plugin.canBypass(p))) {
                rm().remove(center);
                e.setDropItems(false);
                b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5),
                        plugin.createItem(center.type, 1));
                p.sendMessage(plugin.msg("removed"));
            } else {
                e.setCancelled(true);
                p.sendMessage(plugin.msg("center-denied"));
            }
            return;
        }

        Region r = rm().getAt(b.getLocation());
        if (!plugin.allowed(p, r, "build")) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("denied"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Region r = rm().getAt(e.getBlock().getLocation());
        if (!plugin.allowed(e.getPlayer(), r, "build")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(plugin.msg("denied"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        Region r = rm().getAt(e.getBlock().getLocation());
        if (!plugin.allowed(e.getPlayer(), r, "build")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(plugin.msg("denied"));
        }
    }

    // ---------- Взаимодействие (сундуки, двери, кнопки) ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        if (e.getHand() != EquipmentSlot.HAND) return;

        Player p = e.getPlayer();
        Block b = e.getClickedBlock();
        Region r = rm().getAt(b.getLocation());
        if (r == null) return;

        // ПКМ пустой рукой по блоку привата — открыть плашку региона
        if (r.isCenter(b) && p.getInventory().getItemInMainHand().getType() == Material.AIR) {
            e.setCancelled(true);
            plugin.regionGui().open(p, r);
            return;
        }

        if (!isInteractive(b)) return;
        if (!plugin.allowed(p, r, "interact")) {
            e.setUseInteractedBlock(Event.Result.DENY);
            e.setUseItemInHand(Event.Result.DENY);
            p.sendMessage(plugin.msg("denied"));
        }
    }

    private boolean isInteractive(Block b) {
        Material m = b.getType();
        return b.getState() instanceof Container
                || Tag.DOORS.isTagged(m)
                || Tag.TRAPDOORS.isTagged(m)
                || Tag.FENCE_GATES.isTagged(m)
                || Tag.BUTTONS.isTagged(m)
                || Tag.BEDS.isTagged(m)
                || Tag.ANVIL.isTagged(m)
                || m == Material.LEVER
                || m == Material.CRAFTING_TABLE
                || m == Material.ENCHANTING_TABLE
                || m == Material.FURNACE
                || m == Material.BEACON;
    }

    // ---------- PvP ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Entity damager = e.getDamager();
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Entity shooter) {
            damager = shooter;
        }
        if (!(damager instanceof Player attacker)) return;

        Region r = rm().getAt(victim.getLocation());
        if (r != null && !r.flag("pvp") && !plugin.canBypass(attacker)) {
            e.setCancelled(true);
        }
    }

    // ---------- Взрывы ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        // Регион получает "удар" только если взрыв задел САМ приват-блок (центр),
        // а не просто территорию привата. Считаем до фильтрации блоков.
        Set<Region> hit = new LinkedHashSet<>();
        if (e.getEntity() instanceof TNTPrimed || e.getEntity() instanceof ExplosiveMinecart) {
            Location loc = e.getLocation();
            for (Block b : e.blockList()) {
                Region r = rm().getByCenter(b);
                if (r != null) hit.add(r);
            }
            // Запасной вариант для очень прочных блоков (обсидиан и т.п.), которые
            // не попадают в список разрушаемых: взрыв прямо рядом с блоком привата.
            double dist = plugin.getConfig().getDouble("tnt-center-hit-distance", 1.5);
            if (dist > 0) {
                for (Region r : rm().all()) {
                    if (!r.world.equals(loc.getWorld().getName())) continue;
                    double dx = loc.getX() - (r.x + 0.5);
                    double dy = loc.getY() - (r.y + 0.5);
                    double dz = loc.getZ() - (r.z + 0.5);
                    if (dx * dx + dy * dy + dz * dz <= dist * dist) hit.add(r);
                }
            }
        }

        e.blockList().removeIf(this::protectedFromExplosion);

        for (Region r : hit) registerTnt(r);
    }

    /** +1 взрыв TNT региону; при достижении лимита регион разрушается. */
    private void registerTnt(Region r) {
        ConfigurationSection s = plugin.type(r.type);
        int limit = s == null ? 0 : s.getInt("tnt-to-break", 0);
        if (limit <= 0) return; // 0 = от TNT не ломается

        r.tntHits++;
        String name = r.name == null
                ? plugin.getConfig().getString("messages.no-name", "без названия")
                : r.name;

        if (r.tntHits >= limit) {
            rm().remove(r);
            World w = Bukkit.getWorld(r.world);
            if (w != null) w.getBlockAt(r.x, r.y, r.z).setType(Material.AIR);
            notifyMembers(r, plugin.msg("tnt-broken", "%name%", name));
        } else {
            notifyMembers(r, plugin.msg("tnt-hit", "%name%", name,
                    "%hits%", String.valueOf(r.tntHits), "%limit%", String.valueOf(limit)));
        }
    }

    private void notifyMembers(Region r, String text) {
        Player owner = Bukkit.getPlayer(r.owner);
        if (owner != null) owner.sendMessage(text);
        for (UUID u : r.members) {
            Player m = Bukkit.getPlayer(u);
            if (m != null) m.sendMessage(text);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(this::protectedFromExplosion);
    }

    private boolean protectedFromExplosion(Block b) {
        Region r = rm().getAt(b.getLocation());
        return r != null && (r.isCenter(b) || !r.flag("explosion"));
    }

    // ---------- Огонь ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        Region r = rm().getAt(e.getBlock().getLocation());
        if (r != null && (r.isCenter(e.getBlock()) || !r.flag("fire"))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        Region r = rm().getAt(e.getBlock().getLocation());
        if (r == null || r.flag("fire")) return;
        Player p = e.getPlayer();
        if (p != null && plugin.allowed(p, r, "build")) return; // участник может поджечь сам
        e.setCancelled(true);
    }

    // ---------- Поршни не должны двигать блок привата ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (rm().getByCenter(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (rm().getByCenter(b) != null) {
                e.setCancelled(true);
                return;
            }
        }
    }
}

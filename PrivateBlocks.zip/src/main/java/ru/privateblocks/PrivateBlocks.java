package ru.privateblocks;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public class PrivateBlocks extends JavaPlugin {

    private RegionManager regions;
    private SettingsGui settingsGui;
    private MenuGui menuGui;
    private RegionGui regionGui;
    private SizeSelector sizeSelector;
    private PrankManager pranks;
    private ClaimStorage claims;
    private NamespacedKey typeKey;
    private final Set<UUID> bypass = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        typeKey = new NamespacedKey(this, "pb_type");
        regions = new RegionManager(this);
        regions.load();
        claims = new ClaimStorage(this);

        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        settingsGui = new SettingsGui(this);
        getServer().getPluginManager().registerEvents(settingsGui, this);
        menuGui = new MenuGui(this);
        getServer().getPluginManager().registerEvents(menuGui, this);
        getServer().getPluginManager().registerEvents(new IntrusionListener(this), this);
        regionGui = new RegionGui(this);
        getServer().getPluginManager().registerEvents(regionGui, this);
        sizeSelector = new SizeSelector(this);
        getServer().getPluginManager().registerEvents(sizeSelector, this);
        pranks = new PrankManager(this);
        pranks.start();

        PbCommand cmd = new PbCommand(this);
        Objects.requireNonNull(getCommand("pb")).setExecutor(cmd);
        Objects.requireNonNull(getCommand("pb")).setTabCompleter(cmd);

        long ticks = Math.max(1, getConfig().getLong("autosave-minutes", 5)) * 60L * 20L;
        getServer().getScheduler().runTaskTimer(this, () -> {
            regions.save();
            claims.save();
        }, ticks, ticks);
    }

    @Override
    public void onDisable() {
        if (sizeSelector != null) sizeSelector.endAll();
        if (pranks != null) pranks.resetAll();
        if (regions != null) regions.save();
        if (claims != null) claims.save();
    }

    public RegionManager regions() {
        return regions;
    }

    public SettingsGui settingsGui() {
        return settingsGui;
    }

    public MenuGui menuGui() {
        return menuGui;
    }

    public RegionGui regionGui() {
        return regionGui;
    }

    public PrankManager pranks() {
        return pranks;
    }

    public SizeSelector sizeSelector() {
        return sizeSelector;
    }

    public ClaimStorage claims() {
        return claims;
    }

    public Set<UUID> bypassSet() {
        return bypass;
    }

    public boolean canBypass(Player p) {
        return bypass.contains(p.getUniqueId()) || p.hasPermission("privateblocks.bypass");
    }

    /** Тип блока с no-bypass: true — даже /rg bypass не даёт строить, только владелец и тиммейты. */
    public boolean noBypass(Region r) {
        ConfigurationSection s = type(r.type);
        return s != null && s.getBoolean("no-bypass", false);
    }

    /** Можно ли игроку совершить действие (по флагу) в регионе r. */
    public boolean allowed(Player p, Region r, String flag) {
        if (r == null || r.isMember(p.getUniqueId()) || r.flag(flag)) return true;
        return !noBypass(r) && canBypass(p);
    }

    /**
     * Может ли игрок менять флаг региона.
     * Флаг взрывов (explosion) — только у операторов (/op), независимо от конфига и прав.
     */
    public boolean canEditFlag(Player p, Region r, String flag) {
        if (!Region.ALL_FLAGS.contains(flag)) return false;
        if (flag.equals("explosion")) return p.isOp();
        if (canBypass(p)) return true;
        if (!r.owner.equals(p.getUniqueId())) return false;
        ConfigurationSection s = type(r.type);
        return s != null && s.getStringList("editable-flags").contains(flag);
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    /** msg("key", "%a%", "1", "%b%", "2") */
    public String msg(String key, String... repl) {
        String s = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < repl.length; i += 2) {
            s = s.replace(repl[i], repl[i + 1]);
        }
        return color(getConfig().getString("messages.prefix", "") + s);
    }

    public ConfigurationSection type(String id) {
        ConfigurationSection blocks = getConfig().getConfigurationSection("blocks");
        return blocks == null ? null : blocks.getConfigurationSection(id);
    }

    public Set<String> typeIds() {
        ConfigurationSection blocks = getConfig().getConfigurationSection("blocks");
        return blocks == null ? Set.of() : blocks.getKeys(false);
    }

    /** Типы, видимые в меню игроков: без тех, у кого в конфиге hidden: true (например, admin). */
    public List<String> visibleTypeIds() {
        List<String> out = new ArrayList<>();
        for (String id : typeIds()) {
            ConfigurationSection s = type(id);
            if (s != null && !s.getBoolean("hidden", false)) out.add(id);
        }
        return out;
    }

    public ItemStack createItem(String typeId, int amount) {
        ConfigurationSection s = type(typeId);
        if (s == null) return null;
        Material mat = Material.matchMaterial(s.getString("material", "GOLD_BLOCK"));
        if (mat == null || !mat.isBlock()) mat = Material.GOLD_BLOCK;
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(s.getString("name", typeId)));
            List<String> lore = new ArrayList<>();
            for (String line : s.getStringList("lore")) lore.add(color(line));
            meta.setLore(lore);
            meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, typeId);
            item.setItemMeta(meta);
        }
        return item;
    }

    /** Возвращает id типа, если предмет — приват-блок, иначе null. */
    public String typeOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
    }
}

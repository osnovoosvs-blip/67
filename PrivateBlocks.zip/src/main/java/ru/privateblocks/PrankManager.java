package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.EntityEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.WeatherType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Безобидные «приколы» для нежеланных гостей привата (не участников региона).
 * Ничего из этого не наносит урон и не трогает инвентарь.
 * Включаются владельцем командой /rg prank <прикол> on|off.
 */
public class PrankManager {

    /** id -> название для игрока */
    public static final Map<String, String> NAMES = new LinkedHashMap<>();

    static {
        NAMES.put("levitate", "Левитация (взлетает и плавно падает)");
        NAMES.put("glow", "Подсветка (виден сквозь стены)");
        NAMES.put("nausea", "Тошнота (качает экран)");
        NAMES.put("slow", "Замедление");
        NAMES.put("darkness", "Темнота");
        NAMES.put("scare", "Испуг (крик и надпись)");
        NAMES.put("lightning", "Молнии (только эффект, без урона)");
        NAMES.put("particles", "Злые частицы вокруг");
        NAMES.put("push", "Выталкивание из привата");
        NAMES.put("spin", "Вертушка (случайный поворот камеры)");
        NAMES.put("lookdown", "Взгляд в пол (камера смотрит вниз)");
        NAMES.put("chat", "Шёпот (жутковатые сообщения в чат)");
        NAMES.put("sounds", "Странные звуки вокруг");
        NAMES.put("heartbeat", "Стук сердца (Варден рядом)");
        NAMES.put("fakeboom", "Фейк-взрыв (шипение крипера и бабах без урона)");
        NAMES.put("hurt", "Фейк-удар (красная вспышка и «ох», урона нет)");
        NAMES.put("freeze", "Заморозка (на пару секунд почти не двигается)");
        NAMES.put("zoomies", "Дикая скорость (не управляется)");
        NAMES.put("kangaroo", "Кенгуру (супер-прыжки, без урона от падения)");
        NAMES.put("rain", "Личный дождь только для него");
        NAMES.put("night", "Личная ночь только для него");
    }

    public static final List<String> ALL = new ArrayList<>(NAMES.keySet());

    private static final Sound[] WEIRD_SOUNDS = {
            Sound.ENTITY_CREEPER_PRIMED, Sound.ENTITY_ENDERMAN_SCREAM, Sound.ENTITY_VILLAGER_NO,
            Sound.ENTITY_CAT_AMBIENT, Sound.ENTITY_PHANTOM_AMBIENT, Sound.ENTITY_GHAST_AMBIENT,
            Sound.ENTITY_SKELETON_AMBIENT, Sound.ENTITY_ZOMBIE_AMBIENT, Sound.ENTITY_CHICKEN_AMBIENT,
            Sound.ENTITY_PIG_AMBIENT
    };

    private static final List<String> DEFAULT_CHAT = List.of(
            "&8Я вижу тебя...", "&7За тобой уже выехали.", "&8Ты точно хотел сюда зайти?",
            "&7Тут кто-то дышит за спиной.", "&8Не оборачивайся.", "&7Хозяин уже в курсе.");

    /** игроки, у которых мы подменили личную погоду/время (чтобы вернуть при выходе из привата) */
    private final Set<UUID> sky = new HashSet<>();
    private final Set<UUID> skyNow = new HashSet<>();

    private final PrivateBlocks plugin;

    public PrankManager(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long ticks = Math.max(1, plugin.getConfig().getInt("prank-interval-seconds", 4)) * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 60L, ticks);
    }

    // ---------- Команда /rg prank [прикол] [on|off] ----------

    public void command(Player p, Region r, String[] args) {
        if (args.length < 2) {
            p.sendMessage(plugin.msg("prank-header"));
            for (Map.Entry<String, String> e : NAMES.entrySet()) {
                boolean on = r.pranks.contains(e.getKey());
                p.sendMessage(PrivateBlocks.color((on ? "&a[вкл] " : "&7[выкл] ") + "&f" + e.getKey()
                        + " &8- &7" + e.getValue()));
            }
            p.sendMessage(plugin.msg("prank-usage"));
            return;
        }

        String name = args[1].toLowerCase(Locale.ROOT);
        boolean all = name.equals("all");
        if (!all && !NAMES.containsKey(name)) {
            p.sendMessage(plugin.msg("prank-unknown", "%list%", String.join(", ", ALL) + ", all"));
            return;
        }

        boolean value;
        if (args.length >= 3) {
            String v = args[2].toLowerCase(Locale.ROOT);
            if (v.equals("on") || v.equals("true") || v.equals("вкл")) value = true;
            else if (v.equals("off") || v.equals("false") || v.equals("выкл")) value = false;
            else {
                p.sendMessage(plugin.msg("prank-usage"));
                return;
            }
        } else {
            value = all || !r.pranks.contains(name); // без значения — переключить
        }

        if (all) {
            if (value) r.pranks.addAll(ALL);
            else r.pranks.clear();
        } else if (value) {
            r.pranks.add(name);
        } else {
            r.pranks.remove(name);
        }
        plugin.regions().save();
        p.sendMessage(plugin.msg("prank-set", "%name%", name, "%value%", value ? "включён" : "выключен"));
    }

    // ---------- Применение ----------

    private void tick() {
        skyNow.clear();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) continue;
            Region r = plugin.regions().getAt(p.getLocation());
            if (r == null || r.pranks.isEmpty() || r.isMember(p.getUniqueId())) continue;
            for (String prank : new ArrayList<>(r.pranks)) apply(p, r, prank);
        }
        // вернуть обычную погоду и время тем, кто вышел из привата
        for (UUID id : new ArrayList<>(sky)) {
            if (skyNow.contains(id)) continue;
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) {
                pl.resetPlayerWeather();
                pl.resetPlayerTime();
            }
            sky.remove(id);
        }
    }

    /** Вернуть всем обычное небо (при выключении плагина). */
    public void resetAll() {
        for (UUID id : new ArrayList<>(sky)) {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) {
                pl.resetPlayerWeather();
                pl.resetPlayerTime();
            }
        }
        sky.clear();
    }

    private void apply(Player p, Region r, String prank) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Location loc = p.getLocation();
        switch (prank) {
            case "levitate" -> {
                effect(p, "levitation", 40, 3);
                effect(p, "slow_falling", 260, 0); // чтобы не получить урон от падения
            }
            case "glow" -> effect(p, "glowing", 120, 0);
            case "nausea" -> effect(p, "nausea", 160, 0);
            case "slow" -> effect(p, "slowness", 100, 1);
            case "darkness" -> effect(p, "darkness", 100, 0);
            case "scare" -> {
                if (rnd.nextInt(3) == 0) {
                    p.playSound(loc, Sound.ENTITY_GHAST_SCREAM, 1f, 0.7f);
                    p.sendTitle(
                            PrivateBlocks.color(plugin.getConfig().getString("messages.prank-title", "&c&lТебе тут не рады!")),
                            PrivateBlocks.color(plugin.getConfig().getString("messages.prank-subtitle", "&7Уходи...")),
                            5, 30, 10);
                }
            }
            case "lightning" -> {
                if (rnd.nextInt(2) == 0 && loc.getWorld() != null) {
                    // strikeLightningEffect — только визуал и звук, без урона и огня
                    loc.getWorld().strikeLightningEffect(loc.clone().add(rnd.nextInt(-4, 5), 0, rnd.nextInt(-4, 5)));
                }
            }
            case "particles" -> {
                if (loc.getWorld() != null) {
                    loc.getWorld().spawnParticle(Particle.ANGRY_VILLAGER, loc.clone().add(0, 1.2, 0), 12, 0.6, 0.6, 0.6, 0);
                }
            }
            case "push" -> {
                if (p.isInsideVehicle()) return;
                Vector v = loc.toVector().subtract(new Vector(r.x + 0.5, loc.getY(), r.z + 0.5)).setY(0);
                if (v.lengthSquared() < 0.0001) {
                    v = new Vector(rnd.nextDouble(-1, 1), 0, rnd.nextDouble(-1, 1));
                }
                v.normalize().multiply(0.9).setY(0.3);
                p.setVelocity(v);
            }
            case "spin" -> {
                if (p.isInsideVehicle() || rnd.nextInt(3) == 0) return;
                Location l = p.getLocation();
                l.setYaw(rnd.nextFloat() * 360f - 180f);
                p.teleport(l);
            }
            case "lookdown" -> {
                if (p.isInsideVehicle() || rnd.nextInt(2) == 0) return;
                Location l = p.getLocation();
                l.setPitch(90f);
                p.teleport(l);
            }
            case "chat" -> {
                if (rnd.nextInt(3) != 0) return;
                List<String> lines = plugin.getConfig().getStringList("prank-chat-lines");
                if (lines.isEmpty()) lines = DEFAULT_CHAT;
                p.sendMessage(PrivateBlocks.color(lines.get(rnd.nextInt(lines.size()))));
            }
            case "sounds" -> {
                if (rnd.nextInt(2) == 0) return;
                Location at = loc.clone().add(rnd.nextInt(-5, 6), 0, rnd.nextInt(-5, 6));
                p.playSound(at, WEIRD_SOUNDS[rnd.nextInt(WEIRD_SOUNDS.length)], 1f, 0.6f + rnd.nextFloat());
            }
            case "heartbeat" -> p.playSound(loc, Sound.ENTITY_WARDEN_HEARTBEAT, 1.5f, 1f);
            case "fakeboom" -> {
                if (rnd.nextInt(3) != 0 || loc.getWorld() == null) return;
                p.playSound(loc, Sound.ENTITY_CREEPER_PRIMED, 1f, 1f);
                Location boom = loc.clone().add(rnd.nextInt(-3, 4), 0, rnd.nextInt(-3, 4));
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!p.isOnline()) return;
                    // только эффект и звук, настоящего взрыва нет
                    p.spawnParticle(Particle.EXPLOSION_EMITTER, boom, 1);
                    p.playSound(boom, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                }, 30L);
            }
            case "hurt" -> {
                if (rnd.nextInt(3) != 0) return;
                try {
                    p.playEffect(EntityEffect.HURT); // красная вспышка, урона нет
                } catch (Exception ignored) {
                }
                p.playSound(loc, Sound.ENTITY_PLAYER_HURT, 1f, 1f);
            }
            case "freeze" -> {
                effect(p, "slowness", 50, 10);
                effect(p, "jump_boost", 50, 128); // отрицательный прыжок = не прыгнуть
            }
            case "zoomies" -> effect(p, "speed", 100, 4);
            case "kangaroo" -> {
                effect(p, "jump_boost", 100, 4);
                effect(p, "slow_falling", 260, 0); // без урона от падения
            }
            case "rain" -> {
                p.setPlayerWeather(WeatherType.DOWNFALL);
                sky.add(p.getUniqueId());
                skyNow.add(p.getUniqueId());
            }
            case "night" -> {
                p.setPlayerTime(18000L, false);
                sky.add(p.getUniqueId());
                skyNow.add(p.getUniqueId());
            }
            default -> {
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void effect(Player p, String key, int ticks, int amplifier) {
        PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(key));
        if (t != null) p.addPotionEffect(new PotionEffect(t, ticks, amplifier, false, false, false));
    }
}

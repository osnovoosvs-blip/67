package ru.privateblocks;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Считает, сколько бесплатных приват-блоков каждого типа игрок уже получил в меню. */
public class ClaimStorage {

    private final PrivateBlocks plugin;
    private final File file;
    private final YamlConfiguration yml;

    public ClaimStorage(PrivateBlocks plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "claims.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
    }

    public int get(UUID player, String type) {
        return yml.getInt(player + "." + type, 0);
    }

    public void add(UUID player, String type) {
        yml.set(player + "." + type, get(player, type) + 1);
    }

    public void save() {
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить claims.yml: " + ex.getMessage());
        }
    }
}

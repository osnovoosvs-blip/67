package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Меню настроек типов приват-блоков. Работает только у операторов (/op).
 * Изменения сохраняются в config.yml. Уже созданные приваты не меняются —
 * новые настройки применяются к приватам, которые поставят после изменения.
 */
public class SettingsGui implements Listener {

    private static final List<String> FLAGS = Region.ALL_FLAGS;
    private static final int[] FLAG_SLOTS = {19, 20, 21, 22, 23};
    private static final int[] EDIT_SLOTS = {28, 29, 30, 31, 32};

    private final PrivateBlocks plugin;

    public SettingsGui(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    /** Холдер, по которому мы узнаём наши меню. type == null — главное меню. */
    static class Holder implements InventoryHolder {
        final String type;
        Inventory inv;

        Holder(String type) {
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    // ---------- Открытие меню ----------

    public void openMain(Player p) {
        if (!p.isOp()) {
            p.sendMessage(plugin.msg("op-only"));
            return;
        }
        Holder h = new Holder(null);
        Inventory inv = Bukkit.createInventory(h, 27, PrivateBlocks.color("&8Настройки приватов"));
        h.inv = inv;

        int slot = 0;
        for (String id : plugin.typeIds()) {
            if (slot >= 27) break;
            ConfigurationSection s = plugin.type(id);
            if (s == null) continue;
            inv.setItem(slot++, item(material(s), "&e" + id,
                    "&7Радиус: &f" + s.getInt("radius"),
                    "&7Лимит: &f" + limitText(s.getInt("max-per-player", 0)),
                    "",
                    "&aКлик — открыть настройки"));
        }
        p.openInventory(inv);
    }

    public void openType(Player p, String typeId) {
        if (!p.isOp()) {
            p.sendMessage(plugin.msg("op-only"));
            return;
        }
        if (plugin.type(typeId) == null) return;
        Holder h = new Holder(typeId);
        Inventory inv = Bukkit.createInventory(h, 36, PrivateBlocks.color("&8Приват: " + typeId));
        h.inv = inv;
        render(inv, typeId);
        p.openInventory(inv);
    }

    private void render(Inventory inv, String typeId) {
        ConfigurationSection s = plugin.type(typeId);
        if (s == null) return;
        inv.clear();

        inv.setItem(10, item(Material.COMPASS, "&eРадиус: &f" + s.getInt("radius", 5),
                "&7ЛКМ: +1   ПКМ: -1", "&7Shift+ЛКМ: +5   Shift+ПКМ: -5",
                "&8Только для новых приватов"));
        int max = s.getInt("max-per-player", 0);
        inv.setItem(11, item(Material.CHEST, "&eЛимит на игрока: &f" + limitText(max),
                "&7ЛКМ: +1   ПКМ: -1", "&7Shift+ЛКМ: +5   Shift+ПКМ: -5", "&80 = без лимита"));
        int tnt = s.getInt("tnt-to-break", 0);
        inv.setItem(13, item(Material.TNT, "&eTNT до разрушения: &f" + (tnt <= 0 ? "не ломается" : tnt),
                "&7ЛКМ: +1   ПКМ: -1", "&7Shift+ЛКМ: +5   Shift+ПКМ: -5",
                "&80 = регион не ломается от TNT"));
        inv.setItem(12, toggle(s.getBoolean("full-height", true), "&eВся высота",
                "&7Включено: от bedrock до неба", "&7Выключено: ± радиус по Y"));

        inv.setItem(18, item(Material.PAPER, "&6Флаги по умолчанию",
                "&7Зелёный = разрешено ЧУЖИМ игрокам", "&7Красный = запрещено"));
        inv.setItem(27, item(Material.PAPER, "&6Владелец может менять флаг сам",
                "&7Зелёный = может (/pb flag)", "&7Красный = не может"));

        List<String> editable = s.getStringList("editable-flags");
        for (int i = 0; i < FLAGS.size(); i++) {
            String flag = FLAGS.get(i);
            inv.setItem(FLAG_SLOTS[i], toggle(s.getBoolean("flags." + flag, false),
                    "&e" + flagName(flag), "&7Клик — переключить"));
            if (flag.equals("explosion")) {
                inv.setItem(EDIT_SLOTS[i], item(Material.BARRIER, "&e" + flagName(flag),
                        "&cТолько операторы (/op)", "&7Игрокам недоступно"));
            } else {
                inv.setItem(EDIT_SLOTS[i], toggle(editable.contains(flag),
                        "&e" + flagName(flag), "&7Клик — переключить"));
            }
        }

        inv.setItem(35, item(Material.ARROW, "&cНазад"));
    }

    // ---------- Клики ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (!p.isOp()) {
            p.closeInventory();
            p.sendMessage(plugin.msg("op-only"));
            return;
        }
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;

        int slot = e.getSlot();

        // Главное меню
        if (h.type == null) {
            List<String> ids = new ArrayList<>(plugin.typeIds());
            if (slot >= 0 && slot < ids.size()) openType(p, ids.get(slot));
            return;
        }

        // Меню типа
        ConfigurationSection s = plugin.type(h.type);
        if (s == null) {
            p.closeInventory();
            return;
        }
        String path = "blocks." + h.type + ".";

        if (slot == 35) {
            openMain(p);
            return;
        }

        int delta = switch (e.getClick()) {
            case LEFT -> 1;
            case RIGHT -> -1;
            case SHIFT_LEFT -> 5;
            case SHIFT_RIGHT -> -5;
            default -> 0;
        };

        if (slot == 10 && delta != 0) {
            int r = Math.max(1, Math.min(200, s.getInt("radius", 5) + delta));
            plugin.getConfig().set(path + "radius", r);
        } else if (slot == 11 && delta != 0) {
            int m = Math.max(0, Math.min(1000, s.getInt("max-per-player", 0) + delta));
            plugin.getConfig().set(path + "max-per-player", m);
        } else if (slot == 13 && delta != 0) {
            int t = Math.max(0, Math.min(1000, s.getInt("tnt-to-break", 0) + delta));
            plugin.getConfig().set(path + "tnt-to-break", t);
        } else if (slot == 12) {
            plugin.getConfig().set(path + "full-height", !s.getBoolean("full-height", true));
        } else {
            boolean handled = false;
            for (int i = 0; i < FLAGS.size(); i++) {
                String flag = FLAGS.get(i);
                if (slot == FLAG_SLOTS[i]) {
                    plugin.getConfig().set(path + "flags." + flag, !s.getBoolean("flags." + flag, false));
                    handled = true;
                    break;
                }
                if (slot == EDIT_SLOTS[i]) {
                    if (flag.equals("explosion")) {
                        p.sendMessage(plugin.msg("explosion-op-only"));
                        return;
                    }
                    List<String> list = new ArrayList<>(s.getStringList("editable-flags"));
                    if (!list.remove(flag)) list.add(flag);
                    plugin.getConfig().set(path + "editable-flags", list);
                    handled = true;
                    break;
                }
            }
            if (!handled) return;
        }

        plugin.saveConfig();
        render(e.getInventory(), h.type);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ---------- Помощники ----------

    private ItemStack toggle(boolean on, String name, String... lore) {
        List<String> l = new ArrayList<>();
        l.add(on ? "&aВключено" : "&cВыключено");
        l.addAll(List.of(lore));
        return item(on ? Material.LIME_CONCRETE : Material.RED_CONCRETE, name, l.toArray(new String[0]));
    }

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(PrivateBlocks.color(name));
            List<String> l = new ArrayList<>();
            for (String line : lore) l.add(PrivateBlocks.color(line));
            meta.setLore(l);
            it.setItemMeta(meta);
        }
        return it;
    }

    private Material material(ConfigurationSection s) {
        Material m = Material.matchMaterial(s.getString("material", "GOLD_BLOCK"));
        return m == null ? Material.GOLD_BLOCK : m;
    }

    private String limitText(int max) {
        return max <= 0 ? "без лимита" : String.valueOf(max);
    }

    private String flagName(String flag) {
        return switch (flag) {
            case "build" -> "Строительство (build)";
            case "interact" -> "Сундуки и двери (interact)";
            case "pvp" -> "PvP (pvp)";
            case "explosion" -> "Взрывы (explosion)";
            case "fire" -> "Огонь (fire)";
            default -> flag;
        };
    }
}

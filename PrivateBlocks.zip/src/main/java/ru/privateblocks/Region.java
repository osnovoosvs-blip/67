package ru.privateblocks;

import org.bukkit.Location;
import org.bukkit.block.Block;

import java.util.*;

public class Region {

    public static final List<String> ALL_FLAGS = List.of("build", "interact", "pvp", "explosion", "fire");

    public final UUID id;
    public final UUID owner;
    public final Set<UUID> members = new HashSet<>();
    public final String world;
    public final int x, y, z, radius;
    public final String type;
    public final boolean fullHeight;
    public final Map<String, Boolean> flags = new HashMap<>();
    public String name; // необязательное название региона
    public final Set<String> pranks = new HashSet<>(); // включённые приколы для гостей
    public int tntHits;  // сколько TNT уже взорвалось у региона

    public Region(UUID id, UUID owner, String world, int x, int y, int z, int radius, String type, boolean fullHeight) {
        this.id = id;
        this.owner = owner;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.radius = radius;
        this.type = type;
        this.fullHeight = fullHeight;
    }

    public boolean flag(String name) {
        return flags.getOrDefault(name, false);
    }

    public boolean isMember(UUID uuid) {
        return owner.equals(uuid) || members.contains(uuid);
    }

    public boolean isCenter(Block b) {
        return b.getWorld().getName().equals(world) && b.getX() == x && b.getY() == y && b.getZ() == z;
    }

    // ----- Границы -----

    /** true, если размер задан вручную двумя точками (кроватями). */
    public boolean custom;
    public int cMinX, cMaxX, cMinY, cMaxY, cMinZ, cMaxZ;

    public static final int WORLD_MIN_Y = -2048;
    public static final int WORLD_MAX_Y = 4096;

    public int minX() { return custom ? cMinX : x - radius; }
    public int maxX() { return custom ? cMaxX : x + radius; }
    public int minZ() { return custom ? cMinZ : z - radius; }
    public int maxZ() { return custom ? cMaxZ : z + radius; }
    public int minY() { return custom ? cMinY : (fullHeight ? WORLD_MIN_Y : y - radius); }
    public int maxY() { return custom ? cMaxY : (fullHeight ? WORLD_MAX_Y : y + radius); }

    public void setBounds(int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        this.custom = true;
        this.cMinX = minX;
        this.cMaxX = maxX;
        this.cMinY = minY;
        this.cMaxY = maxY;
        this.cMinZ = minZ;
        this.cMaxZ = maxZ;
    }

    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;
        int bx = l.getBlockX(), by = l.getBlockY(), bz = l.getBlockZ();
        return bx >= minX() && bx <= maxX()
                && by >= minY() && by <= maxY()
                && bz >= minZ() && bz <= maxZ();
    }

    public boolean intersectsBox(String w, int ax, int bx, int ay, int by, int az, int bz) {
        if (!world.equals(w)) return false;
        return minX() <= bx && maxX() >= ax
                && minY() <= by && maxY() >= ay
                && minZ() <= bz && maxZ() >= az;
    }

    public boolean intersects(Region o) {
        return intersectsBox(o.world, o.minX(), o.maxX(), o.minY(), o.maxY(), o.minZ(), o.maxZ());
    }
}

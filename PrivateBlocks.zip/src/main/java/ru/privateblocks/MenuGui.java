package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Красивое меню для всех игроков: /rg (или /rg menu).
 * Типы с "free: true" в config.yml можно получить бесплатно (до free-limit раз).
 */
public class MenuGui implements Listener {

    private static final int[] TYPE_SLOTS = {10, 11, 12, 13, 14, 15, 16};
    private static final int SLOT_MY = 21;
    private static final int SLOT_INFO = 22;
    private static final int SLOT_SETTINGS = 23;
    private static final int SLOT_CLOSE = 31;

    private final PrivateBlocks plugin;

    public MenuGui(PrivateBlocks plugin) {
        this.plugin = plugin;
    }

    static class Holder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    public void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 36, PrivateBlocks.color("&6&lПриваты"));
        h.inv = inv;
        render(inv, p);
        p.openInventory(inv);
    }

    private void render(Inventory inv, Player p) {
        inv.clear();

        // Фон и рамка
        ItemStack bg = pane(Material.GRAY_STAINED_GLASS_PANE);
        ItemStack frame = pane(Material.ORANGE_STAINED_GLASS_PANE);
        for (int i = 0; i < 36; i++) {
            boolean edge = i < 9 || i >= 27 || i % 9 == 0 || i % 9 == 8;
            inv.setItem(i, edge ? frame : bg);
        }

        // Типы приват-блоков (порядок как в config.yml, самый слабый — первым)
        List<String> ids = plugin.visibleTypeIds();
        for (int i = 0; i < TYPE_SLOTS.length && i < ids.size(); i++) {
            ConfigurationSection s = plugin.type(ids.get(i));
            if (s != null) inv.setItem(TYPE_SLOTS[i], typeItem(p, ids.get(i), s));
        }

        // Кнопки
        int mine = plugin.regions().ownedBy(p.getUniqueId()).size();
        inv.setItem(SLOT_MY, item(Material.BOOK, "&eМои приваты",
                "&7Всего: &f" + mine, "", "&aКлик — показать список"));
        inv.setItem(SLOT_INFO, item(Material.COMPASS, "&eТекущий приват",
                "&7Плашка привата,", "&7в котором ты стоишь", "", "&aКлик — открыть"));
        if (p.isOp()) {
            inv.setItem(SLOT_SETTINGS, item(Material.NETHER_STAR, "&dНастройки &7(оп)",
                    "&7Радиус, лимиты и флаги", "&7всех типов блоков", "", "&aКлик — открыть"));
        }
        inv.setItem(SLOT_CLOSE, item(Material.BARRIER, "&cЗакрыть"));
    }

    private ItemStack typeItem(Player p, String id, ConfigurationSection s) {
        boolean free = s.getBoolean("free", false);
        int limit = s.getInt("free-limit", 1);
        int claimed = plugin.claims().get(p.getUniqueId(), id);
        int r = s.getInt("radius", 5);
        int size = r * 2 + 1;

        List<String> lore = new ArrayList<>();
        for (String line : s.getStringList("lore")) lore.add(line);
        lore.add("");
        lore.add("&7Размер: &f" + size + "×" + size
                + (s.getBoolean("full-height", true) ? " &7(вся высота)" : "×" + size));
        int max = s.getInt("max-per-player", 0);
        lore.add("&7Лимит на игрока: &f" + (max <= 0 ? "без лимита" : max));
        int tnt = s.getInt("tnt-to-break", 0);
        lore.add("&7Ломается от: &f" + (tnt <= 0 ? "не ломается" : tnt + " TNT"));
        lore.add("&7Защита от чужих: &f" + protectedList(s));
        lore.add("");
        if (!free) {
            lore.add("&cНедоступно — выдаётся администрацией");
        } else if (claimed >= limit && !plugin.canBypass(p)) {
            lore.add("&cУже получено (" + claimed + "/" + limit + ")");
        } else {
            lore.add("&aЛКМ — получить бесплатно (" + claimed + "/" + limit + ")");
        }

        Material m = Material.matchMaterial(s.getString("material", "GOLD_BLOCK"));
        if (m == null) m = Material.GOLD_BLOCK;
        return item(m, s.getString("name", id), lore.toArray(new String[0]));
    }

    private String protectedList(ConfigurationSection s) {
        List<String> out = new ArrayList<>();
        for (String flag : Region.ALL_FLAGS) {
            if (!s.getBoolean("flags." + flag, false)) out.add(flagWord(flag));
        }
        return out.isEmpty() ? "нет" : String.join(", ", out);
    }

    private String flagWord(String flag) {
        return switch (flag) {
            case "build" -> "строительство";
            case "interact" -> "сундуки и двери";
            case "pvp" -> "PvP";
            case "explosion" -> "взрывы";
            case "fire" -> "огонь";
            default -> flag;
        };
    }

    // ---------- Клики ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;

        int slot = e.getSlot();

        List<String> ids = plugin.visibleTypeIds();
        for (int i = 0; i < TYPE_SLOTS.length && i < ids.size(); i++) {
            if (slot == TYPE_SLOTS[i]) {
                claim(p, ids.get(i), e.getInventory());
                return;
            }
        }

        switch (slot) {
            case SLOT_MY -> {
                p.closeInventory();
                p.performCommand("pb list");
            }
            case SLOT_INFO -> {
                p.closeInventory();
                Region r = plugin.regions().getAt(p.getLocation());
                if (r == null) {
                    p.sendMessage(plugin.msg("not-in-region"));
                } else {
                    plugin.regionGui().open(p, r);
                }
            }
            case SLOT_SETTINGS -> {
                if (p.isOp()) plugin.settingsGui().openMain(p);
            }
            case SLOT_CLOSE -> p.closeInventory();
            default -> {
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void claim(Player p, String id, Inventory inv) {
        ConfigurationSection s = plugin.type(id);
        if (s == null) return;
        if (s.getBoolean("hidden", false)) {
            p.sendMessage(plugin.msg("not-free"));
            return;
        }

        if (!p.hasPermission("privateblocks.use")) {
            p.sendMessage(plugin.msg("no-permission"));
            return;
        }
        if (!s.getBoolean("free", false)) {
            p.sendMessage(plugin.msg("not-free"));
            return;
        }
        int limit = s.getInt("free-limit", 1);
        if (plugin.claims().get(p.getUniqueId(), id) >= limit && !plugin.canBypass(p)) {
            p.sendMessage(plugin.msg("claim-limit"));
            return;
        }

        ItemStack item = plugin.createItem(id, 1);
        if (item == null) return;
        p.getInventory().addItem(item).values()
                .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
        plugin.claims().add(p.getUniqueId(), id);
        plugin.claims().save();
        p.sendMessage(plugin.msg("claimed", "%type%", id));
        render(inv, p);
    }

    // ---------- Помощники ----------

    private ItemStack pane(Material m) {
        return item(m, " ");
    }

    private ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(PrivateBlocks.color(name));
            List<String> l = new ArrayList<>();
            for (String line : lore) l.add(PrivateBlocks.color(line));
            meta.setLore(l);
            it.setItemMeta(meta);
        }
        return it;
    }
}

package ru.privateblocks;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class RegionManager {

    private final PrivateBlocks plugin;
    private final File file;
    private final List<Region> regions = new ArrayList<>();

    public RegionManager(PrivateBlocks plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "regions.yml");
    }

    public List<Region> all() {
        return regions;
    }

    public void add(Region r) {
        regions.add(r);
    }

    public void remove(Region r) {
        regions.remove(r);
    }

    public Region getAt(Location loc) {
        for (Region r : regions) {
            if (r.contains(loc)) return r;
        }
        return null;
    }

    public Region byId(UUID id) {
        for (Region r : regions) {
            if (r.id.equals(id)) return r;
        }
        return null;
    }

    public Region getByCenter(Block b) {
        for (Region r : regions) {
            if (r.isCenter(b)) return r;
        }
        return null;
    }

    public int count(UUID owner, String type) {
        int n = 0;
        for (Region r : regions) {
            if (r.owner.equals(owner) && r.type.equals(type)) n++;
        }
        return n;
    }

    public List<Region> ownedBy(UUID owner) {
        List<Region> list = new ArrayList<>();
        for (Region r : regions) {
            if (r.owner.equals(owner)) list.add(r);
        }
        return list;
    }

    public void load() {
        regions.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yml.getConfigurationSection("regions");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            try {
                Region r = new Region(
                        UUID.fromString(key),
                        UUID.fromString(Objects.requireNonNull(s.getString("owner"))),
                        s.getString("world", "world"),
                        s.getInt("x"), s.getInt("y"), s.getInt("z"),
                        s.getInt("radius"),
                        s.getString("type", "small"),
                        s.getBoolean("full-height", true));
                if (s.isConfigurationSection("bounds")) {
                    r.setBounds(s.getInt("bounds.min-x"), s.getInt("bounds.max-x"),
                            s.getInt("bounds.min-y"), s.getInt("bounds.max-y"),
                            s.getInt("bounds.min-z"), s.getInt("bounds.max-z"));
                }
                r.name = s.getString("name");
                r.tntHits = s.getInt("tnt-hits", 0);
                for (String m : s.getStringList("members")) r.members.add(UUID.fromString(m));
                r.pranks.addAll(s.getStringList("pranks"));
                ConfigurationSection f = s.getConfigurationSection("flags");
                if (f != null) {
                    for (String name : f.getKeys(false)) r.flags.put(name, f.getBoolean(name));
                }
                regions.add(r);
            } catch (Exception ex) {
                plugin.getLogger().warning("Не удалось загрузить регион " + key + ": " + ex.getMessage());
            }
        }
        plugin.getLogger().info("Загружено приватов: " + regions.size());
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Region r : regions) {
            String p = "regions." + r.id + ".";
            yml.set(p + "owner", r.owner.toString());
            yml.set(p + "world", r.world);
            yml.set(p + "x", r.x);
            yml.set(p + "y", r.y);
            yml.set(p + "z", r.z);
            yml.set(p + "radius", r.radius);
            yml.set(p + "type", r.type);
            yml.set(p + "full-height", r.fullHeight);
            if (r.custom) {
                yml.set(p + "bounds.min-x", r.cMinX);
                yml.set(p + "bounds.max-x", r.cMaxX);
                yml.set(p + "bounds.min-y", r.cMinY);
                yml.set(p + "bounds.max-y", r.cMaxY);
                yml.set(p + "bounds.min-z", r.cMinZ);
                yml.set(p + "bounds.max-z", r.cMaxZ);
            }
            if (r.name != null) yml.set(p + "name", r.name);
            if (r.tntHits > 0) yml.set(p + "tnt-hits", r.tntHits);
            if (!r.pranks.isEmpty()) yml.set(p + "pranks", new ArrayList<>(r.pranks));
            List<String> members = new ArrayList<>();
            for (UUID m : r.members) members.add(m.toString());
            yml.set(p + "members", members);
            for (Map.Entry<String, Boolean> e : r.flags.entrySet()) {
                yml.set(p + "flags." + e.getKey(), e.getValue());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить regions.yml: " + ex.getMessage());
        }
    }
}

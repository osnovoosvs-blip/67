package ru.privateblocks;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Задание размера привата двумя кроватями.
 * Инвентарь игрока прячется (сохраняется и на диск тоже), выдаются 2 кровати:
 * красная = «Первая точка», синяя = «Вторая точка». После установки обеих точек
 * (или отмены / выхода / таймаута) инвентарь возвращается.
 */
public class SizeSelector implements Listener {

    private static class Session {
        final UUID regionId;
        final ItemStack[] saved;
        Block p1;
        Block p2;
        BukkitTask timeout;

        Session(UUID regionId, ItemStack[] saved) {
            this.regionId = regionId;
            this.saved = saved;
        }
    }

    private final PrivateBlocks plugin;
    private final NamespacedKey pointKey;
    private final File file;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public SizeSelector(PrivateBlocks plugin) {
        this.plugin = plugin;
        this.pointKey = new NamespacedKey(plugin, "pb_point");
        this.file = new File(plugin.getDataFolder(), "size-sessions.yml");
    }

    // ---------- Команда /rg size [cancel] ----------

    public void command(Player p, String[] args) {
        UUID id = p.getUniqueId();
        if (args.length > 1 && args[1].equalsIgnoreCase("cancel")) {
            if (sessions.containsKey(id)) {
                restore(id);
                p.sendMessage(plugin.msg("size-cancelled"));
            } else {
                p.sendMessage(plugin.msg("size-no-session"));
            }
            return;
        }
        if (sessions.containsKey(id)) {
            p.sendMessage(plugin.msg("size-in-session"));
            return;
        }
        Region r = plugin.regions().getAt(p.getLocation());
        if (r == null) {
            p.sendMessage(plugin.msg("not-in-region"));
            return;
        }
        if (!(r.owner.equals(id) || plugin.canBypass(p))) {
            p.sendMessage(plugin.msg("not-owner"));
            return;
        }
        ConfigurationSection ts = plugin.type(r.type);
        if (ts == null || !ts.getBoolean("custom-size", false)) {
            p.sendMessage(plugin.msg("size-not-allowed"));
            return;
        }
        start(p, r);
    }

    // ---------- Старт / конец ----------

    public void start(Player p, Region r) {
        UUID id = p.getUniqueId();
        if (sessions.containsKey(id)) return;

        ItemStack[] saved = p.getInventory().getContents();
        Session s = new Session(r.id, saved);
        sessions.put(id, s);
        persist(id, saved);

        p.getInventory().clear();
        p.getInventory().setItem(3, pointItem(1));
        p.getInventory().setItem(4, pointItem(2));
        p.getInventory().setHeldItemSlot(3);
        p.updateInventory();

        int seconds = Math.max(10, plugin.getConfig().getInt("size-timeout-seconds", 300));
        s.timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (sessions.get(id) == s) {
                restore(id);
                Player pl = Bukkit.getPlayer(id);
                if (pl != null) pl.sendMessage(plugin.msg("size-timeout"));
            }
        }, seconds * 20L);

        p.sendMessage(plugin.msg("size-start", "%seconds%", String.valueOf(seconds)));
    }

    /** Вернуть инвентарь и закрыть сессию. */
    private void restore(UUID id) {
        Session s = sessions.remove(id);
        if (s == null) return;
        if (s.timeout != null) s.timeout.cancel();
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            p.getInventory().setContents(s.saved);
            p.updateInventory();
        }
        clearPersisted(id);
    }

    /** При выключении плагина — вернуть всем инвентарь. */
    public void endAll() {
        for (UUID id : new ArrayList<>(sessions.keySet())) restore(id);
    }

    public boolean inSession(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    // ---------- Предметы ----------

    private ItemStack pointItem(int n) {
        ItemStack it = new ItemStack(n == 1 ? Material.RED_BED : Material.BLUE_BED);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(PrivateBlocks.color(n == 1 ? "&cПервая точка" : "&9Вторая точка"));
            meta.setLore(List.of(
                    PrivateBlocks.color("&7ПКМ по блоку — поставить точку"),
                    PrivateBlocks.color("&7Отмена: &f/rg size cancel")));
            meta.getPersistentDataContainer().set(pointKey, PersistentDataType.INTEGER, n);
            it.setItemMeta(meta);
        }
        return it;
    }

    private Integer pointOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        ItemMeta meta = it.getItemMeta();
        return meta == null ? null : meta.getPersistentDataContainer().get(pointKey, PersistentDataType.INTEGER);
    }

    // ---------- Установка точек ----------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return;

        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        e.setCancelled(true);

        if (e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Integer pt = pointOf(e.getItem());
        Block b = e.getClickedBlock();
        if (pt == null || b == null) return;

        if (pt == 1) s.p1 = b;
        else s.p2 = b;
        p.sendMessage(plugin.msg(pt == 1 ? "size-point1" : "size-point2",
                "%x%", String.valueOf(b.getX()), "%y%", String.valueOf(b.getY()),
                "%z%", String.valueOf(b.getZ())));

        if (s.p1 != null && s.p2 != null) apply(p, s);
    }

    private void apply(Player p, Session s) {
        UUID id = p.getUniqueId();
        Region r = plugin.regions().byId(s.regionId);
        if (r == null) {
            restore(id);
            p.sendMessage(plugin.msg("size-cancelled"));
            return;
        }
        if (!s.p1.getWorld().equals(s.p2.getWorld()) || !s.p1.getWorld().getName().equals(r.world)) {
            p.sendMessage(plugin.msg("size-other-world"));
            s.p1 = null;
            s.p2 = null;
            return;
        }

        ConfigurationSection ts = plugin.type(r.type);
        boolean tall = ts != null && ts.getBoolean("full-height", false);

        int minX = Math.min(s.p1.getX(), s.p2.getX());
        int maxX = Math.max(s.p1.getX(), s.p2.getX());
        int minZ = Math.min(s.p1.getZ(), s.p2.getZ());
        int maxZ = Math.max(s.p1.getZ(), s.p2.getZ());
        int minY = tall ? Region.WORLD_MIN_Y : Math.min(s.p1.getY(), s.p2.getY());
        int maxY = tall ? Region.WORLD_MAX_Y : Math.max(s.p1.getY(), s.p2.getY());

        int max = plugin.getConfig().getInt("custom-size-max", 300);
        if (max > 0 && (maxX - minX + 1 > max || maxZ - minZ + 1 > max || (!tall && maxY - minY + 1 > max))) {
            p.sendMessage(plugin.msg("size-too-big", "%max%", String.valueOf(max)));
            s.p1 = null;
            s.p2 = null;
            return;
        }

        if (r.x < minX || r.x > maxX || r.y < minY || r.y > maxY || r.z < minZ || r.z > maxZ) {
            p.sendMessage(plugin.msg("size-center-outside"));
            s.p1 = null;
            s.p2 = null;
            return;
        }

        for (Region other : plugin.regions().all()) {
            if (other != r && other.intersectsBox(r.world, minX, maxX, minY, maxY, minZ, maxZ)) {
                p.sendMessage(plugin.msg("size-overlap"));
                s.p1 = null;
                s.p2 = null;
                return;
            }
        }

        r.setBounds(minX, maxX, minY, maxY, minZ, maxZ);
        plugin.regions().save();
        restore(id);
        p.sendMessage(plugin.msg("size-done",
                "%sx%", String.valueOf(maxX - minX + 1),
                "%sz%", String.valueOf(maxZ - minZ + 1),
                "%sy%", tall ? "∞" : String.valueOf(maxY - minY + 1)));
    }

    // ---------- Защита от выноса кроватей и действий во время разметки ----------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent e) {
        if (sessions.containsKey(e.getPlayer().getUniqueId()) || pointOf(e.getItemInHand()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent e) {
        if (sessions.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrop(PlayerDropItemEvent e) {
        if (sessions.containsKey(e.getPlayer().getUniqueId()) || pointOf(e.getItemDrop().getItemStack()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (sessions.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && sessions.containsKey(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getWhoClicked() instanceof Player p && sessions.containsKey(p.getUniqueId())) e.setCancelled(true);
    }

    // ---------- Выход, смерть, вход ----------

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        restore(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (sessions.containsKey(e.getEntity().getUniqueId())) {
            e.getDrops().removeIf(it -> pointOf(it) != null);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (sessions.containsKey(id)) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (sessions.containsKey(id)) {
                    restore(id);
                    Player pl = Bukkit.getPlayer(id);
                    if (pl != null) pl.sendMessage(plugin.msg("size-restored"));
                }
            });
        }
    }

    /** Если сервер упал во время разметки — вернуть инвентарь при входе. */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (sessions.containsKey(id) || !file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        List<?> list = yml.getList(id.toString());
        if (list == null) return;
        ItemStack[] items = new ItemStack[list.size()];
        for (int i = 0; i < items.length; i++) {
            Object o = list.get(i);
            items[i] = o instanceof ItemStack it ? it : null;
        }
        p.getInventory().setContents(items);
        p.updateInventory();
        clearPersisted(id);
        p.sendMessage(plugin.msg("size-restored"));
    }

    // ---------- Файл на случай сбоя ----------

    private void persist(UUID id, ItemStack[] items) {
        YamlConfiguration yml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        yml.set(id.toString(), Arrays.asList(items));
        saveFile(yml);
    }

    private void clearPersisted(UUID id) {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        if (!yml.contains(id.toString())) return;
        yml.set(id.toString(), null);
        saveFile(yml);
    }

    private void saveFile(YamlConfiguration yml) {
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить size-sessions.yml: " + ex.getMessage());
        }
    }
}

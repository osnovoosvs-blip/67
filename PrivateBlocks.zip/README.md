# PrivateBlocks

Приват-блоки для Spigot/Paper 1.21.11 (Java 21). Настройка — в `config.yml`.

## Сборка через GitHub
1. Залей содержимое репозитория на GitHub.
2. Вкладка **Actions** → **Build** → дождись зелёной галочки.
3. Открой запуск → раздел **Artifacts** → скачай `PrivateBlocks` (внутри JAR).
4. Положи JAR в папку `plugins/` сервера.

Локально: `mvn package` → `target/PrivateBlocks-1.0.0.jar`.
